// The PartyBox - Main JavaScript
// Enhanced with dynamic image loading from JSON data

// Global variables
let websiteData = {};
let currentCategory = 'all';
let lightboxInstance = null;

// Initialize the website
document.addEventListener('DOMContentLoaded', function() {
    console.log('🎉 The PartyBox website initializing...');
    
    // Load website data first
    loadWebsiteData()
        .then(() => {
            console.log('✅ Website data loaded successfully');
            initializeWebsite();
        })
        .catch(error => {
            console.error('❌ Failed to load website data:', error);
            showFallbackContent();
        });
});

// Load website data from JSON
async function loadWebsiteData() {
    try {
        const response = await fetch('data/website-data.json');
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        websiteData = await response.json();
        console.log('📊 Website data loaded:', websiteData);
    } catch (error) {
        console.error('❌ Error loading website data:', error);
        throw error;
    }
}

// Initialize website components
function initializeWebsite() {
    initializeNavigation();
    initializeHeroSection();
    initializeGallery();
    initializeTestimonials();
    initializeContactForm();
    initializeClickToCall();
    initializeScrollEffects();
    initializeServiceWorker();
    
    console.log('✅ Website initialization complete');
}

// Initialize navigation
function initializeNavigation() {
    const mobileMenuToggle = document.querySelector('.mobile-menu-toggle');
    const navMenu = document.querySelector('.nav-menu');
    const navLinks = document.querySelectorAll('.nav-link');
    
    if (mobileMenuToggle) {
        mobileMenuToggle.addEventListener('click', function(e) {
            e.preventDefault();
            navMenu.classList.toggle('active');
            this.classList.toggle('active');
        });
    }
    
    // Close mobile menu when clicking on links
    navLinks.forEach(link => {
        link.addEventListener('click', () => {
            navMenu.classList.remove('active');
            if (mobileMenuToggle) mobileMenuToggle.classList.remove('active');
        });
    });
    
    // Smooth scrolling for navigation links
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function (e) {
            e.preventDefault();
            const target = document.querySelector(this.getAttribute('href'));
            if (target) {
                target.scrollIntoView({
                    behavior: 'smooth',
                    block: 'start'
                });
            }
        });
    });
}

// Initialize hero section
function initializeHeroSection() {
    const heroTitle = document.querySelector('.hero-title');
    const heroSubtitle = document.querySelector('.hero-subtitle');
    const heroDescription = document.querySelector('.hero-description');
    const heroImage = document.querySelector('.hero-image');
    
    if (websiteData.hero) {
        if (heroTitle) heroTitle.textContent = websiteData.hero.title;
        if (heroSubtitle) heroSubtitle.textContent = websiteData.hero.subtitle;
        if (heroDescription) heroDescription.textContent = websiteData.hero.description;
        if (heroImage && websiteData.hero.image) {
            heroImage.src = websiteData.hero.image;
            heroImage.alt = websiteData.hero.title;
        }
    }
}

// Initialize gallery with dynamic image loading
function initializeGallery() {
    const galleryGrid = document.querySelector('.gallery-grid');
    const categoryButtons = document.querySelectorAll('.category-btn');
    
    if (!galleryGrid || !websiteData.gallery) return;
    
    // Set up category buttons
    categoryButtons.forEach(btn => {
        btn.addEventListener('click', function() {
            const category = this.dataset.category;
            filterGallery(category);
            
            // Update active button
            categoryButtons.forEach(b => b.classList.remove('active'));
            this.classList.add('active');
        });
    });
    
    // Load initial gallery
    loadGalleryImages('all');
    
    // Initialize lightbox
    initializeLightbox();
}

// Load gallery images dynamically
function loadGalleryImages(category) {
    const galleryGrid = document.querySelector('.gallery-grid');
    if (!galleryGrid || !websiteData.gallery) return;
    
    // Clear existing images
    galleryGrid.innerHTML = '';
    
    // Get images for the selected category
    let imagesToShow = [];
    
    if (category === 'all') {
        // Show all images from all categories
        websiteData.gallery.categories.forEach(cat => {
            if (cat.images) {
                imagesToShow = imagesToShow.concat(cat.images);
            }
        });
    } else {
        // Show images from specific category
        const categoryData = websiteData.gallery.categories.find(cat => cat.id === category);
        if (categoryData && categoryData.images) {
            imagesToShow = categoryData.images;
        }
    }
    
    // Create image elements with loading states
    imagesToShow.forEach((image, index) => {
        const galleryItem = createGalleryItem(image, index);
        galleryGrid.appendChild(galleryItem);
    });
    
    // Add loading animation
    animateGalleryItems();
}

// Create gallery item with proper image loading
function createGalleryItem(image, index) {
    const item = document.createElement('div');
    item.className = 'gallery-item';
    item.dataset.category = image.tags ? image.tags[0] : 'all';
    
    item.innerHTML = `
        <div class="gallery-image-wrapper">
            <img 
                src="${image.url}" 
                alt="${image.title}"
                class="gallery-image"
                loading="lazy"
                data-index="${index}"
            />
            <div class="gallery-overlay">
                <div class="gallery-content">
                    <h3 class="gallery-title">${image.title}</h3>
                    <p class="gallery-description">${image.description}</p>
                    <div class="gallery-tags">
                        ${image.tags ? image.tags.map(tag => `<span class="gallery-tag">${tag}</span>`).join('') : ''}
                    </div>
                    <button class="view-btn" data-image="${image.url}" data-title="${image.title}">
                        <i class="fas fa-eye"></i> View
                    </button>
                </div>
            </div>
            <div class="image-loading">
                <i class="fas fa-spinner fa-spin"></i>
            </div>
        </div>
    `;
    
    // Handle image loading
    const img = item.querySelector('.gallery-image');
    const loadingElement = item.querySelector('.image-loading');
    
    img.addEventListener('load', function() {
        loadingElement.style.display = 'none';
        this.classList.add('loaded');
    });
    
    img.addEventListener('error', function() {
        loadingElement.innerHTML = '<i class="fas fa-image"></i>';
        loadingElement.style.background = '#f0f0f0';
        loadingElement.style.color = '#999';
        console.warn(`Failed to load image: ${image.url}`);
    });
    
    return item;
}

// Filter gallery by category
function filterGallery(category) {
    currentCategory = category;
    loadGalleryImages(category);
}

// Initialize lightbox functionality
function initializeLightbox() {
    const lightbox = document.querySelector('.lightbox');
    const lightboxImage = document.querySelector('.lightbox-image');
    const lightboxTitle = document.querySelector('.lightbox-title');
    const lightboxDescription = document.querySelector('.lightbox-description');
    const closeLightbox = document.querySelector('.close-lightbox');
    const prevBtn = document.querySelector('.lightbox-prev');
    const nextBtn = document.querySelector('.lightbox-next');
    
    let currentImageIndex = 0;
    let currentImages = [];
    
    // Close lightbox
    function closeLightboxHandler() {
        lightbox.classList.remove('active');
        document.body.style.overflow = '';
    }
    
    if (closeLightbox) {
        closeLightbox.addEventListener('click', closeLightboxHandler);
    }
    
    // Close on overlay click
    lightbox.addEventListener('click', function(e) {
        if (e.target === this) {
            closeLightboxHandler();
        }
    });
    
    // ESC key to close
    document.addEventListener('keydown', function(e) {
        if (e.key === 'Escape' && lightbox.classList.contains('active')) {
            closeLightboxHandler();
        }
    });
    
    // View button click handlers
    document.addEventListener('click', function(e) {
        if (e.target.closest('.view-btn')) {
            e.preventDefault();
            const btn = e.target.closest('.view-btn');
            const imageUrl = btn.dataset.image;
            const title = btn.dataset.title;
            
            // Get current gallery images
            currentImages = getCurrentGalleryImages();
            currentImageIndex = currentImages.findIndex(img => img.url === imageUrl);
            
            openLightbox(currentImageIndex);
        }
    });
    
    // Navigation
    if (prevBtn) {
        prevBtn.addEventListener('click', function() {
            if (currentImages.length > 0) {
                currentImageIndex = (currentImageIndex - 1 + currentImages.length) % currentImages.length;
                updateLightboxImage();
            }
        });
    }
    
    if (nextBtn) {
        nextBtn.addEventListener('click', function() {
            if (currentImages.length > 0) {
                currentImageIndex = (currentImageIndex + 1) % currentImages.length;
                updateLightboxImage();
            }
        });
    }
    
    function openLightbox(index) {
        currentImageIndex = index;
        updateLightboxImage();
        lightbox.classList.add('active');
        document.body.style.overflow = 'hidden';
    }
    
    function updateLightboxImage() {
        if (currentImages.length === 0) return;
        
        const currentImage = currentImages[currentImageIndex];
        lightboxImage.src = currentImage.url;
        lightboxImage.alt = currentImage.title;
        lightboxTitle.textContent = currentImage.title;
        lightboxDescription.textContent = currentImage.description;
    }
}

// Get current gallery images based on active category
function getCurrentGalleryImages() {
    let images = [];
    
    if (currentCategory === 'all') {
        websiteData.gallery.categories.forEach(cat => {
            if (cat.images) {
                images = images.concat(cat.images);
            }
        });
    } else {
        const category = websiteData.gallery.categories.find(cat => cat.id === currentCategory);
        if (category && category.images) {
            images = category.images;
        }
    }
    
    return images;
}

// Animate gallery items
function animateGalleryItems() {
    const galleryItems = document.querySelectorAll('.gallery-item');
    
    galleryItems.forEach((item, index) => {
        setTimeout(() => {
            item.classList.add('animate-in');
        }, index * 100);
    });
}

// Initialize testimonials carousel
function initializeTestimonials() {
    const testimonialsContainer = document.querySelector('.testimonials-container');
    const testimonialCards = document.querySelectorAll('.testimonial-card');
    const prevBtn = document.querySelector('.testimonial-prev');
    const nextBtn = document.querySelector('.testimonial-next');
    
    if (!testimonialsContainer || testimonialCards.length === 0) return;
    
    let currentTestimonial = 0;
    
    function showTestimonial(index) {
        testimonialCards.forEach((card, i) => {
            card.classList.toggle('active', i === index);
        });
    }
    
    function nextTestimonial() {
        currentTestimonial = (currentTestimonial + 1) % testimonialCards.length;
        showTestimonial(currentTestimonial);
    }
    
    function prevTestimonial() {
        currentTestimonial = (currentTestimonial - 1 + testimonialCards.length) % testimonialCards.length;
        showTestimonial(currentTestimonial);
    }
    
    if (nextBtn) {
        nextBtn.addEventListener('click', nextTestimonial);
    }
    
    if (prevBtn) {
        prevBtn.addEventListener('click', prevTestimonial);
    }
    
    // Auto-rotate testimonials
    setInterval(nextTestimonial, 5000);
    
    // Show first testimonial
    showTestimonial(0);
}

// Initialize contact form
function initializeContactForm() {
    const contactForm = document.querySelector('.contact-form');
    const quoteForm = document.querySelector('.quote-form');
    
    [contactForm, quoteForm].forEach(form => {
        if (!form) return;
        
        form.addEventListener('submit', function(e) {
            e.preventDefault();
            
            const formData = new FormData(this);
            const submitBtn = this.querySelector('.submit-btn');
            const originalText = submitBtn.textContent;
            
            // Show loading state
            submitBtn.textContent = 'Sending...';
            submitBtn.disabled = true;
            
            // Simulate form submission
            setTimeout(() => {
                // Show success message
                showNotification('Thank you! Your message has been sent successfully.', 'success');
                this.reset();
                
                // Reset button
                submitBtn.textContent = originalText;
                submitBtn.disabled = false;
            }, 2000);
        });
    });
}

// Initialize click-to-call functionality
function initializeClickToCall() {
    const phoneNumber = websiteData.business?.phone || '01708 898374';
    const clickToCallButtons = document.querySelectorAll('.click-to-call');
    
    clickToCallButtons.forEach(btn => {
        btn.href = `tel:${phoneNumber.replace(/\s/g, '')}`;
        btn.addEventListener('click', function() {
            console.log('📞 Click-to-call activated:', phoneNumber);
        });
    });
}

// Initialize scroll effects
function initializeScrollEffects() {
    const observerOptions = {
        threshold: 0.1,
        rootMargin: '0px 0px -50px 0px'
    };
    
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('animate-in');
            }
        });
    }, observerOptions);
    
    // Observe elements for animation
    document.querySelectorAll('.feature-card, .service-card, .testimonial-card').forEach(el => {
        observer.observe(el);
    });
}

// Initialize Service Worker for offline functionality
function initializeServiceWorker() {
    if ('serviceWorker' in navigator) {
        navigator.serviceWorker.register('/sw.js')
            .then(function(registration) {
                console.log('✅ ServiceWorker registered:', registration.scope);
            })
            .catch(function(error) {
                console.log('❌ ServiceWorker registration failed:', error);
            });
    }
}

// Show notification
function showNotification(message, type = 'info') {
    const notification = document.createElement('div');
    notification.className = `notification notification-${type}`;
    notification.textContent = message;
    
    document.body.appendChild(notification);
    
    // Animate in
    setTimeout(() => {
        notification.classList.add('show');
    }, 100);
    
    // Remove after 5 seconds
    setTimeout(() => {
        notification.classList.remove('show');
        setTimeout(() => {
            document.body.removeChild(notification);
        }, 300);
    }, 5000);
}

// Show fallback content if JSON fails to load
function showFallbackContent() {
    console.warn('⚠️ Showing fallback content due to JSON loading failure');
    
    // Show basic content without images
    const heroImage = document.querySelector('.hero-image');
    if (heroImage) {
        heroImage.src = 'data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iODAwIiBoZWlnaHQ9IjYwMCIgdmlld0JveD0iMCAwIDgwMCA2MDAiIGZpbGw9Im5vbmUiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+CjxyZWN0IHdpZHRoPSI4MDAiIGhlaWdodD0iNjAwIiBmaWxsPSIjZjBmMGYwIi8+Cjx0ZXh0IHg9IjQwMCIgeT0iMzAwIiBmb250LWZhbWlseT0iQXJpYWwiIGZvbnQtc2l6ZT0iMjQiIGZpbGw9IiM5OTk5OTkiIHRleHQtYW5jaG9yPSJtaWRkbGUiPkltYWdlIExvYWRpbmcuLi48L3RleHQ+Cjwvc3ZnPgo=';
        heroImage.alt = 'Hero image placeholder';
    }
    
    // Initialize basic functionality
    initializeNavigation();
    initializeContactForm();
    initializeClickToCall();
    
    showNotification('Some images may not load properly. Please refresh the page.', 'warning');
}

// Utility functions
function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}

// Handle window resize
const handleResize = debounce(() => {
    // Reinitialize components that depend on screen size
    const navMenu = document.querySelector('.nav-menu');
    const mobileMenuToggle = document.querySelector('.mobile-menu-toggle');
    
    if (window.innerWidth > 768) {
        navMenu.classList.remove('active');
        if (mobileMenuToggle) mobileMenuToggle.classList.remove('active');
    }
}, 250);

window.addEventListener('resize', handleResize);

// Page load performance tracking
window.addEventListener('load', function() {
    const loadTime = performance.timing.loadEventEnd - performance.timing.navigationStart;
    console.log(`🚀 Page loaded in ${loadTime}ms`);
});

console.log('🎈 The PartyBox JavaScript loaded successfully!');